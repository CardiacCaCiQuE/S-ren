$(function(){
   //sacar los mensajes de error
    $("errornombreUsuario").hide();
    $("errorCelular").hide();
    $("errorrut").hide();
    $("erroremail").hide();
    
    //variables que indican valor de estado validacion
    var error_username = false;
	var error_celular = false;
	var error_rut = false;
	var error_email = false;
    //focusout ocurre cuando se deja de hacer uso de un elemento como por ejemplo el campo de texto del nombre entonces 
    //ejecuta la funcion chech_username para indicar un mensaje de error en caso de que este mal llenado el campo
    $("#nombreUsuario").focusout(function() {

		check_username();
		
	});

	$("#Celular").focusout(function() {

		check_celular();
		
	});

	$("#rut").focusout(function() {

         check_rut();
		
	});

	$("#email").focusout(function() {

		check_email();
		
	});
//se especifica la funcion
	function check_username() {
	
		var username_length = $("#nombreUsuario").val().length;
		
		if(username_length < 5 || username_length > 20) {
			$("#errornombreUsuario").html("debe tener entre 5 y 20 caracteres");
			$("#errornombreUsuario").show();
			error_username = true;
		} else {
			$("#errornombreUsuario").hide();
		}
	
	}
    
    function check_celular() {
	
		var celular_length = $("#Celular").val().length;
		//se podria poner que que se fuera 0 o 8 sea valido pero quiero que el cliente ingrese un numero jaja
		if(celular_length < 8 || celular_length > 8)  {
			$("#errorCelular").html("debe tener 8 digitos");
			$("#errorCelular").show();
			error_celular = true;
		} else {
			$("#errorCelular").hide();
		}
	
	}

	function check_rut() {
	//RegExp lo que hace es buscar digitos \d y que sean entre 2 y 8 caracteres ya que
	// el menor rut encontrado ha sido 10-8 luego un - seguido de cualquier digito o k-K y que solo sea
	//un caracter https://www.w3schools.com/jsref/jsref_obj_regexp.asp
		var pattern = new RegExp(/\d{2,8}-[\d|kK]{1}/);
		//utiliza el id rut para la prueba
		if(pattern.test($("#rut").val())) {
			$("#errorrut").hide();
		} else {
			$("#errorrut").html("RUT invalido");
			$("#errorrut").show();
			error_email = true;
		}
	// en caso de error sale un mensaje sino el mensaje se mantiene oculto
	}

	function check_email() {

		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
	
		if(pattern.test($("#email").val())) {
			$("#erroremail").hide();
		} else {
			$("#erroremail").html("Direccion de correo inválida");
			$("#erroremail").show();
			error_email = true;
		}
	
	}

	$("#formulario1").submit(function() {
					
		error_username = false;
        error_celular = false;
        error_rut = false;
        error_email = false;						
												
		check_username();
		check_email();
		check_celular();
		check_rut();
		
		//checkea que todas las alertas se encuentren apagadas
		//para que el boton haga la funcion, en caso contrario
		//retorna falso
		if(error_username == false && error_rut == false && error_celular == false && error_email == false) {
			return true;			
		} else {

			return false;	
		}

	});	


});