from django.conf.urls import url
from . import views

urlpatterns=[
    url(r'^persona$',views.PersonaView.as_view()),
]
