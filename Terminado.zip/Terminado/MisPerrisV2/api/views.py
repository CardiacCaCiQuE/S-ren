from django.shortcuts import render
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth.models import User
from Back.models import Usuario, Mascota
from . import serializers


class PersonaView(APIView):
    def get(self,request):
        personas = Usuario.objects.all()
        serializer = serializers.PersonaSerializer(personas,many=True)
        return Response(serializer.data)

    def post(self,request):
        rut = request.POST.get('rut')
        contra = request.POST.get('contra')
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        email = request.POST.get('email')
        fechaNac = request.POST.get('fechaNacimiento')
        fono = request.POST.get('numeroFono')
        region = request.POST.get('region')
        ciudad = request.POST.get('ciudad')
        vivienda = request.POST.get('vivienda')
        tipo = request.POST.get('tipo') 
        # TOMA LOS DATOS DEL FOMRULARIO
        usuario = User.objects.create_user(username=nombre, password=contra, email=email)        
        usuario.save()
        # REGISTRA AL USUARIO
        return Response()
