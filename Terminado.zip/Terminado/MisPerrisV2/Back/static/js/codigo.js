$(document).ready(function(){
    $("#carrusel").bxSlider({
        slideWidth:700,
        adaptiveHeight:true,
        made:"vertical"
    }
        
    );    
})