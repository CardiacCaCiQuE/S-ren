from rest_framework import serializers
from Back.models import Usuario
# En las instrucciones habia que elegir entre registrar personas o mascotas por lo que elegi registrar a las personas 
# Ese fue el unico cambio que hubo en la aplicacion.
class PersonaSerializer(serializers.ModelSerializer):
    class Meta:
        fields = ('__all__')
        model = Usuario

