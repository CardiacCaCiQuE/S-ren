
from django.http import HttpResponse

# Libreria para renderizar y redirigir a paginas
from django.shortcuts import render, redirect, render_to_response

# Libreraia para cargar plantillas y contexto
from django.template import loader,RequestContext

# Importacion de librerias para validaciones
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password #permite generar una nueva contrasena

# Importacion de modelos y formulario
from .models import Usuario, Mascota, Mensaje
from .forms import Login,Recuperrar, NuevaPass, Contacto, AgregarMascota
# Libreria para enviar mail
from django.core.mail import send_mail
# Create your views here.

# Tuplas con las acciones 
acciones=[
   {'Mostrar':'Home','url':'inicio'}
]
#Index que se mostrara sin la necesidad de estar logeado
def index(request):
    plantilla=loader.get_template("index.html") # se carga la plantilla en este caso index.html
    contexto={ #se carga el diccionario
        'titulo':"titulo",
    }
    return HttpResponse(plantilla.render(contexto,request)) # lo que retorna la view en este caso la plantilla y el contexto

#Index el cual requiere estar logeado para poder verlo

def index2(request):
    plantilla=loader.get_template("index2.html")# se carga la plantilla en este caso index2.html
    contexto={
        'titulo':"titulo",
    }
    return HttpResponse(plantilla.render(contexto,request))

#Logout // cerrar sesion

def salir(request):
    logout(request)# solicita la accion de cerrar sesion
    return redirect('/') # nos cierra sesion y nos dirige a la pagina principal

#Crear Usuarios que ya nbo se usa
#def gestionarUsuarios(request):
 #   actual=request.user
  #  form=AgregarUsuario(request.POST) #se carga la form en este caso agreagr usuario
   # if form.is_valid(): # si la forma es valida entonces 
    #    data=form.cleaned_data # lo usaremos para obtener los valores
     #   regDB=User.objects.create_user(data.get("username"),data.get("correo"),data.get("password")) #usamos regDB porque el profe dijo que era bueno jaja y le pasamos los diferentes datos del form
      #  usuario=Usuario(user=regDB,perfil=data.get("perfil")) # se pasa el perfil de usuaro
       # regDB.save() # se graban los datos
       # usuario.save()
    #usuarios=Usuario.objects.all()
    #form=AgregarUsuario()
    #return render(request,"GestionarUsuarios.html",{'actual':actual,'form':form,'usuarios':usuarios,'acciones':acciones,}) # nos retorna la plantilla gestionarusuarios.html

#Crear Usuarios
def gestionarUsuarios(request):
    registro=1 #Dependiendo este número, es el Formulario que Mostrará
    return render(request,"GestionarUsuarios.html",{'registro':registro,'titulo':"Registro",})

#Login para ingresar al sistema
def ingresar(request):
    form=Login(request.POST or None)
    if form.is_valid():
        data=form.cleaned_data
        user=authenticate(username=data.get("username"),password=data.get("password")) # se carga los datos
        if user is not None: #si el usuario no es NONE entonesces nos redirige al index2 que es solo para usuarios registrados
            login(request,user)
            return redirect('index2')
    return render(request,"login.html",{'form':form,})

@login_required(login_url='login') # se requiere estar logeado para ingresar a esta pagina
def ingresoPerro(request):
    actual=request.user
    usuarios=Mascota.objects.all()
    form=AgregarMascota(request.POST, request.FILES)
    if form.is_valid():
        data=form.cleaned_data
        regDB=Mascota(fotoMascota=data.get("fotoMascota"),nombreMascota=data.get("nombreMascota"),razaMascota=data.get("razaMascota"),descripcionMascota=data.get("descripcionMascota"),estadoMascota=data.get("estadoMascota"))
        regDB.save()
    form = AgregarMascota()
    return render(request, "agregarMascota.html", {'actual':actual,'form':form,'usuarios':usuarios,'acciones':acciones,})

# para ponerse en contacto enviando un correo no esta terminado ya que deberia de enviar un mensaje a mi correo pero aun no tengo establecido eso
def contacto(request):
    msgs=Mensaje.objects.all()
    form=Contacto(request.POST or None)
    variables={
        'form':form,
        'msgs':msgs,
    }
    if form.is_valid():
        datos=form.cleaned_data
        nombreIn=datos.get("nombre")
        emailIn=datos.get("email")
        mensajeIn=datos.get("mensaje")
        regDB=Mensaje(nombre=nombreIn,correo=emailIn,mensaje=mensajeIn)
        regDB.save()
        
    return render(request,"contacto.html",variables)

# ver los perros ingresados en el sistema

    # Recuperacion Contraseña, el usuario ingresa su nombre de usuario entonces el sistema lo identifica e envvia un correo al email registrado al momento de crear la cuenta con un enlace para reestablecer la pass
def recuperrar(request):
    form=Recuperrar(request.POST or None)
    if form.is_valid():
        data=form.cleaned_data
        user=User.objects.get(username=data.get("username"))
        send_mail(
                'Recuperrarcion de Contraseña',#Este es el asunto del correo y esta mal escrito aproposito                
                'Haga click aquí para ingresar una nueva contraseña',
                'MisPerris2018DuocAmd@gmail.com',
                [user.email],
                html_message = 'Estimado: '+user.username+' Pulse aca para reestablecer su password  <a href="http://localhost:8000/nuevapass?user='+user.username+'">aca</a>',
            )
    return render(request,"recuperrar.html",{'form':form,'titulo':"Recuperrarcion de Contraseña",})


# cambiar la contrasena por una nueva
def nuevapass(request):
    form=NuevaPass(request.POST or None) #se carga el form   
    try:
        username=request.GET["user"] #se solicita nombre de usuario
    except Exception as e: # se usa exception as e ya que con esta forma podemos ingresar atributos el cual en este caso es el de no se encuentra el nombre de usuario
        username= None 
    if username is not None: # si se encuetra el noombre de usuariuo entonces se ejecuta la accion
        if form.is_valid():
            data=form.cleaned_data
            if data.get("nueva") == data.get("repite_nueva"): #si las contrasenas ingresadas son iguales entonces se envia un mensaje diciendo que la pass ha sido cambiada
                nueva=make_password(data.get("repite_nueva"))
                User.objects.filter(username=username).update(password=nueva)
        return render(request,"nuevapass.html",{'form':form, 'username':username, 'titulo':"Restablecer Contraseña",})
    else:
        return redirect('login')


# ver los perros ingresados en el sistema
def verPerros(request):
    mascotas=Mascota.objects.all()
    plantilla=loader.get_template("verPerros.html")
    contexto={
        'mascotas':mascotas,
    }
    return HttpResponse(plantilla.render(contexto,request))

# eliminar mascota el cual obtienne el codigo de la mascota y lo elimina de la base de datos y nos vuelve a dirigir a ver mascotas
def eliminarMascota(request, postid):
    mascota=Mascota.objects.filter(codigoMascota=postid) 
    mascota.delete()
    return redirect('verPerros')

def base_layout(request):
  template="maqueta.html"
  return render(request,template)


