from django.conf.urls import url
from django.urls import path
from . import views
# direccion para navegar en los diferentes mundos de la pagina jaja
urlpatterns=[
    url(r'^$',views.index),
    url(r'^index/$',views.index,name="inicio"),
    url(r'^index2/$',views.index2,name="index2"),
    url(r'^Usuarios/$',views.gestionarUsuarios,name="gestionarUsuarios"),
    url(r'^ingresoPerro/$',views.ingresoPerro,name="ingresoPerro"),
    url(r'^verPerros/$',views.verPerros,name="verPerros"),
    url(r'^contacto/$',views.contacto,name="contacto"),
    url(r'^login/$',views.ingresar,name="login"),
    url(r'^salir/$',views.salir,name="logout"),    
    url(r'^eliminarMascota/(?P<postid>\d+)/', views.eliminarMascota, name='eliminarMascota'),#aca se elimina la mascota en base al id que posee
    url(r'^recuperrar/$',views.recuperrar,name="recuperrar"),
    url(r'^nuevapass/$',views.nuevapass,name="nuevapass"),
    path(r'base_layout/',views.base_layout,name='base_layout'),
    
    ]