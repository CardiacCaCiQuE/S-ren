from django.apps import AppConfig


class BackConfig(AppConfig):
    name = 'Back'
